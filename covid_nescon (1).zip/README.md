## Webcovid - Pandemia COVID-19 (para o Brasil - estados e municipios)
### Nescon e DEP (UFMG)

_Diagnóstico e proposta de solução_ para a pandemia de COVID-19 por uma ótica do Núcleo de Estudos em Saúde Coletiva (Nescon), da medicina da UFMG em parceria com a engenharia de produção (DEP) da UFMG.

Equipe:  [João Flávio de Freitas Almeida](<joao.flavio@dep.ufmg.br>)
         [Francisco Cardoso (Chico)](<cardoso@nescon.medicina.ufmg.br>)
         [Luiz Ricardo Pinto](<luiz@dep.ufmg.br>)
         [Samuel Vieira Conceição](<svieira@dep.ufmg.br>)
         [Virginia Magalhães](<vmagalhaes@nescon.medicina.ufmg.br>)

Fontes:
Dados:  [Wesley Cota](https://covid19br.wcota.me/)
SEIR:   [Ryan McGee](https://github.com/ryansmcgee/seirsplus)
Leitos: [Array Advisors](https://www.healthleadersmedia.com/welcome-ad?toURL=/covid-19/see-when-states-will-face-hospital-bed-capacity-shortages-during-covid-19-outbreak)
